<?php
	// MyBB Maintenance Mode plugin U.S. English language file.
	// (C) 2015 CubicleSoft.  All Rights Reserved.

	$l["MaintenanceMode_plugin_Name"] = "Maintenance Mode Plugin";
	$l["MaintenanceMode_plugin_Desc"] = "Closes the board when a file called 'maintenance.txt' exists at the root.  The file could, for example, be placed there via a cron job (e.g. detecting a newer version of MyBB).<br /><a href=\"https://www.paypal.com/cgi-bin/webscr?cmd=_s-xclick&hosted_button_id=244381\" target=\"_blank\" title=\"Donations are highly appreciated and money goes toward further development.\">Donate $5 toward further development</a> - A great way to say thanks or place a feature request.";
	$l["MaintenanceMode_plugin_Author"] = "Thomas Hruska, CubicleSoft Core";
?>