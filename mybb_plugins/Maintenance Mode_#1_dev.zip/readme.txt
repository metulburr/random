**************************** MyBB Maintenance Mode ***************************

MyBB Maintenance Mode plugin.
(C) 2015 CubicleSoft.  All Rights Reserved.

This plugin is free to use with the MyBB forum software package.
Creative Commons License:  http://creativecommons.org/licenses/by-nc-nd/3.0/us



This plugin looks for a file called 'maintenance.txt' at the MyBB root.  If it
exists, users get a message saying the board is closed.  This allows cron jobs
to perform regular maintenance tasks or locking the forum when an upgrade
becomes available.


Installation Instructions:

  - Copy MaintenanceMode.php to /inc/plugins/
  - Copy MaintenanceMode_plugin_admin.lang.php to /inc/languages/english/admin/
  - Log into the Admin panel.
  - Click 'Configuration' at the top.
  - Click 'Plugins' at the left.
  - Click 'Activate'.


Developed by Thomas Hruska, CubicleSoft Core.
http://www.cubiclesoft.com/
