<?php
	// MyBB Maintenance Mode plugin code.
	// (C) 2015 CubicleSoft.  All Rights Reserved.
	//
	// This plugin is free to use with the MyBB forum software package.
	// Closes the board when a file called 'maintenance.txt' exists at the root.  The file could, for example, be placed there via a cron job (e.g. detecting a newer version of MyBB).
	// This plugin replaces two older plugins that didn't work as intended.
	// Creative Commons License:  http://creativecommons.org/licenses/by-nc-nd/3.0/us
	// Developed by Thomas Hruska, CubicleSoft Core.

	// Disallow direct access to this file for security reasons.
	if (!defined("IN_MYBB"))
	{
		die("Direct initialization of this file is not allowed.<br /><br />Please make sure IN_MYBB is defined.");
	}

	// Main hook.
	$plugins->add_hook("global_end", "MaintenanceMode_global_end");

	function MaintenanceMode_info()
	{
		global $lang;

		$lang->load("MaintenanceMode_plugin_admin");

		return Array(
			"name" => $lang->MaintenanceMode_plugin_Name,
			"description" => $lang->MaintenanceMode_plugin_Desc,
			"website" => "http://mods.mybboard.net/view/???",
			"author" => $lang->MaintenanceMode_plugin_Author,
			"authorsite" => "http://www.cubiclesoft.com/",
			"version" => "1.0",
			"guid" => "",
			"compatibility" => "18*"
		);
	}

	function MaintenanceMode_global_end()
	{
		if (file_exists(MYBB_ROOT . "maintenance.txt"))
		{
			global $lang;

			$lang->load("MaintenanceMode_plugin");

			error($lang->sprintf($lang->MaintenanceMode_disabled, htmlspecialchars(file_get_contents(MYBB_ROOT . "maintenance.txt"))));
		}
	}
?>