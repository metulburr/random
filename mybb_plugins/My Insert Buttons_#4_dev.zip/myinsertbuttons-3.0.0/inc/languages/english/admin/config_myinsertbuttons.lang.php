<?php

$l['myinsertbuttons_plug_desc'] = 'Insert new button in Sceditor';
$l['myinsertbuttons_sett_desc'] = 'Settings related to the My Insert Buttons.';
$l['myinsertbuttons_rules_title'] = 'Add new button in Clickable MyCode Editor';
$l['myinsertbuttons_rulesdes_title'] = 'Add new button in Clickable MyCode Editor with Description';
$l['myinsertbuttons_rules_desc'] = 'Enter the button name. You must make sure the rule is valid and safe—no validation is performed. Separate buttons with ",".<br /><strong>Example:</strong> spoiler,test';
$l['myinsertbuttons_imgur_title'] = 'Imgur';
$l['myinsertbuttons_imgur_desc'] = 'Set here API of imgur (Client ID).';
?>