<?php

/**
 * MyBB 1.8
 * Copyright 2010 MyBB Group, All Rights Reserved
 *
 * Website: http://mybb.com
 * License: http://mybb.com/about/license
 *
 * Author: Clear
 * Created: 08/12/2014
 * Version: 4.0
 * Contact: clearwebspacedesign@gmail.com
 * License: Is not allowed the copy, redistribution and sale of this plugin. For all problem, contact me.
 */

if(!defined("IN_MYBB"))
	die("This file cannot be accessed directly.");
	
if (!defined("PLUGINLIBRARY"))
    define("PLUGINLIBRARY", MYBB_ROOT."inc/plugins/pluginlibrary.php");

$plugins->add_hook('global_start', 'guestwarn'); 

function guestwarn_info() {
	return array(
		"name"			=> "Guest Warn",
		"description"	=> "Show an elegant warn for all guest of your forum.",
		"website"		=> "http://www.mybb.com/",
		"author"		=> "Clear",
		"authorsite"	=> "https://www.facebook.com/davide.scanu.94",
		"version"		=> "4.0",
		"guid" 			=> "",
		"compatibility" => "18*"
	);
}

function guestwarn_activate() {
	global $mybb, $db;
	
	if (!file_exists(PLUGINLIBRARY)) {
    flash_message($lang->myalerts_pluginlibrary_missing, "error");
    admin_redirect("index.php?module=config-plugins");
    }

    $PL or require_once PLUGINLIBRARY;

    if ((int) $PL->version < 9) {
    flash_message('This plugin requires PluginLibrary 9 or newer', 'error');
    admin_redirect('index.php?module=config-plugins');
    }

    $stylesheet = "@import url(http://fonts.googleapis.com/css?family=Ubuntu:400,700);
@import url(http://maxcdn.bootstrapcdn.com/font-awesome/4.2.0/css/font-awesome.min.css);
	
.guest_warn {
  background: rgba(0,0,0,0.85);
  width: 300px;
  padding: 28px 23px 28px 23px;
  position: fixed;
  top: 50%;
  right: 50px;
  font-family: 'Ubuntu', sans-serif;
  font-size: 13px;
  color: #fff;
  text-align: left;
  -moz-border-radius: 5px;
  -webkit-border-radius: 5px;
  -o-border-radius: 5px;
  border-radius: 5px;
}

.guest_warn i.fa.fa-close {
  height: 20px;
  width: 20px;
  position: absolute;
  top: 8px;
  right: 8px;
  text-align: center;
  line-height: 20px;
  font-size: 16px;
  cursor: pointer;
}";

    $PL->stylesheet('guestwarn.css', $stylesheet);
	
	$guestwarn_group = array(
		'name' => 'guestwarn', 
		'title' => 'Guest Warn Settings', 
		'description' => "These settings allow an elegant warn for all guest of your forum.", 
		'disporder' => 1,
		'isdefault' => 0
	);
	
	$gid = $db->insert_query("settinggroups", $guestwarn_group);
	
	$guestwarn_1 = array(
		"name"			=> "guestwarn_1",
		"title"			=> "Is enabled?",
		"description"	=> "Set to no if you do not want to display the warn.",
		"optionscode"	=> "yesno",
		"value"			=> 1,
		"disporder"		=> 1,
		"gid"			=> $gid
	);
	$db->insert_query("settings", $guestwarn_1);
	
	$guestwarn_2 = array(
		"name"			=> "guestwarn_2",
		"title"			=> "Message",
		"description"	=> "Enter the text to show in the warn.",
		"optionscode"	=> "textarea",
		"value"			=> 'Hello guest, if you read this it means you are not registered. <a href="member.php?action=register" target="_blank">Click here</a> to register in a few simple steps, you will enjoy all features of our Forum.',
		"disporder"		=> 2,
		"gid"			=> $gid
	);
	$db->insert_query("settings", $guestwarn_2);
	
	$guestwarn_3 = array(
		"name"			=> "guestwarn_3",
		"title"			=> "Seconds until the warn re-appears",
		"description"	=> "Enter the seconds until the warn reappears after a user click the close button. 3600 seconds = 1 hour.",
		"optionscode"	=> "text",
		"value"			=> '3600',
		"disporder"		=> 3,
		"gid"			=> $gid
	);
	$db->insert_query("settings", $guestwarn_3);
	
	$guestwarn_4 = array(
		"name"			=> "guestwarn_4",
		"title"			=> "Who see the warn?",
		"description"	=> "Enter the id of group who should see the warn.",
		"optionscode"	=> "text",
		"value"			=> '1',
		"disporder"		=> 4,
		"gid"			=> $gid
	);
	$db->insert_query("settings", $guestwarn_4);
	
	rebuild_settings();

	$templatearray = array(
		"tid" => "NULL",
		"title" => 'guestwarn',
		"template" => $db->escape_string('<div class="guest_warn"><i class="fa fa-close"></i>{$message}</div>

<script type="text/javascript">
$(document).ready(function() {
  $(".guest_warn").fadeIn("slow");
  $(".guest_warn i.fa.fa-close").click(function() {
    $(".guest_warn").fadeOut("slow");
    $.post(document.location.href, {cookie_guestwarn: 1});
  });
});                      
</script>'),
		"sid" => "-1",
	);

	$db->insert_query("templates", $templatearray);
	
	require_once MYBB_ROOT.'inc/adminfunctions_templates.php';
	
	find_replace_templatesets('headerinclude', '#'.preg_quote('{$stylesheets}').'#i','{$stylesheets} {$guestwarn}');
}

function guestwarn_deactivate() {
	global $db;
	
	if (!file_exists(PLUGINLIBRARY)) {
    flash_message($lang->myalerts_pluginlibrary_missing, "error");
    admin_redirect("index.php?module=config-plugins");
    }

    $PL or require_once PLUGINLIBRARY;

    $PL->stylesheet_delete('guestwarn.css');
	
	$db->delete_query("settinggroups", "name = 'guestwarn'");

	$db->delete_query('settings', 'name IN (\'guestwarn_1\',\'guestwarn_2\',\'guestwarn_3\',\'guestwarn_4\')');

	rebuild_settings();
	
	$db->delete_query('templates', 'title IN (\'guestwarn\') AND sid=\'-1\'');
	
	require_once MYBB_ROOT."inc/adminfunctions_templates.php";
	
	find_replace_templatesets('headerinclude', '#'.preg_quote('{$guestwarn}').'#i', '', 0);
}

function guestwarn() {
	
	global $mybb, $db, $lang, $templates, $guestwarn, $theme;
	
	$message = $mybb->settings['guestwarn_2'];
	
	if ($mybb->user['usergroup'] == $mybb->settings['guestwarn_4']) {
	    if($mybb->settings['guestwarn_1'] == 1) {
		    if(isset($_POST['cookie_guestwarn'])) {
			    setcookie("isclosed", "1", time()+$mybb->settings['guestwarn_3']);
	        }
	        if($_COOKIE['isclosed'] != 1) {
	            eval("\$guestwarn = \"".$templates->get('guestwarn')."\";");
	        }
	    }
	}
}

?>