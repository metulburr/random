Plugin Name: Post Counter
Copyright: � 2014 Pirata Nervo
Website: http://www.mybb-plugins.com
License: license.txt

----- Description
This plugin counts the number of posts and threads of a certain user since a certain date.
This might be helpful for post two "something" websites or contests where users must post to get something.

----- Installation
Upload contents of the Upload folder to the root of your MyBB installation.
Go to Admin CP -> Configuration -> Plugins and Activate "Post Counter"
Then go to Settings -> Post Counter and change anything you need.

----- Upgrading

From 1.1 to 1.2:
- Upload contents of the Upload folder to the root of your MyBB installation.

----- Change Log
1.2
 - Added compatibility with MyBB 1.8.

1.1
 - Added compatibility with MyBB 1.6.
 - Changed license GPLv3.