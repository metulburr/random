<?php
/*
	project: Mobile MyBB 1.8 (MMyBB18)
	file:    MYBB_ROOT/inc/languages/english/mmybb18.lang.php
	version: 1.4.0
	author:  Rickey Gu
	web:     http://flexplat.com
	email:   rickey29@gmail.com
*/

$l['desktop_style'] = 'Desktop Style';
$l['index'] = 'Index';
$l['options'] = 'Options';
$l['personal_footer'] = 'Powered by <a href="http://flexplat.com/" rel="external">FlexPlat</a>, <a href="https://www.mybb.com/" rel="external">MyBB</a> and <a href="http://jquerymobile.com/" rel="external">jQuery Mobile</a>';
$l['personal_header'] = '';
?>